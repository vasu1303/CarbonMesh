# Measurements screen: phase 2

This phase implements `/measurement` only. It is a read-only screen for existing
results, not the Data Intake or calculation workflow. The shared shell now links
Dashboard and Measurements on desktop and mobile; other screen links remain
disabled. The existing dashboard commit is the baseline for this branch.

## Run and preview

- Start the API as described in the repository README and run `npm run dev`.
- Live data: `http://localhost:3000/measurement`.
- Development-only preview: `http://localhost:3000/measurement?source=preview`.
- Switch explicitly using Live API / Synthetic preview. API failures never
  activate preview mode. Switching sources clears the selected record and page.
- Production builds disable preview mode and omit the synthetic fixture bundle.

The screen uses the company, site, reporting period and metric UUIDs already
documented in `apps/web/.env.example`. Synthetic preview supports only the
declared Maverick / Plant B / Q3 2026 identifiers; it does not relabel its records
to match an arbitrary tenant. Live names and provenance come from the API.

## Implemented interactions

- Independent status counts, context, category definitions and result queries.
- Status and metric-category filters, bounded server pagination and page size.
- Filters, page, view, data source and selected record are URL-addressable.
- Records and lazy-loaded chart views. Chart values are individual records on
  the current page, never a summed footprint or a claimed trend.
- Record inspection with facts, recorded confidence components/weights,
  method/code versions, hashes, optional backend baseline comparison, source
  activity rows, factor evidence, calculations and source-to-result lineage.
- Detail and lineage load independently. No row is automatically opened and
  no per-record requests are made for the entire table.
- Draft, verified, superseded and unsupported statuses are distinct.
  Unsupported values are not plotted or presented as zero verified emissions.
- Loading, empty, invalid identifier, contract mismatch, API error, cached-data
  refresh warning and partial-lineage states; retry controls and keyboard focus
  restoration after inspection.

## Canonical backend contracts

| Endpoint | Purpose |
| --- | --- |
| `GET /api/measurements` | Records and counts using API `total` |
| `GET /api/measurements/{measurement_id}` | Inspection facts and evidence |
| `GET /api/measurements/{measurement_id}/lineage` | Persisted lineage |
| `GET /api/semantic/metrics` | Category names and exact metric keys |
| `POST /api/context/resolve` | Read-only reporting context resolution |

Every read carries `company_id`; lists additionally carry `site_id` and
`reporting_period_id`. Category is an exact metric key such as
`emissions.scope3.category1`, not a display label. The backend orders results by
creation time descending with an ID tie-break. No unsupported search, date
range, confidence filter, sort, aggregate, export or category endpoint is invented.

Zod validates consumed API fields and rejects mismatched record/context IDs.
Decimal values remain strings for display. Numeric conversion is used for chart
geometry, not emissions or confidence calculations. Existing confidence v1
components are shown exactly as returned; no silent v2 reinterpretation occurs.

No upload, calculate, provider-sync, approval, seed, reset or database-write
operation is invoked by this screen. Backend source files were not changed.

## Temporary synthetic data

`apps/web/src/features/measurements/preview/measurements.synthetic.json` contains
six explicitly synthetic record snapshots with stable preview-only IDs, response
shapes, evidence references and lineage edges. Preview references exist only in
that fixture. A preview status of `verified` does not mean a database fact exists.

The snapshots were validated with the actual Pydantic `MeasurementSummary`,
`MeasurementDetail`, `MeasurementLineageResult`, `ContextEnvelope` and
`MetricDefinitionList` models. Sample emissions and confidence were generated
offline using Decimal and the existing backend confidence function; the UI does
not run business formulas. Preview is not a golden replay or a database seed.
Later population must use the real backend services to create persisted
calculations, facts and ledger history. Do not insert these UI snapshots as if
they were audited ledger events.

## Checks

From `apps/web`, run `npm run typecheck`, `npm run lint`, `npm run build`, and
`npm run test:e2e`. Browser tests cover the existing dashboard plus Measurements
in light, dark and mobile layouts. Tests use synthetic responses, never mutate a
database, and exercise the real preview adapter as well as intercepted API reads.

To revalidate fixture shapes and Decimal arithmetic using the backend environment,
run from the repository root on Windows:

```powershell
apps/api/.venv/Scripts/python.exe apps/web/tests/measurement-preview-contract.py
```

Use `apps/api/.venv/bin/python` on macOS/Linux. This check reads JSON and imports
Pydantic/domain code only; it does not connect to a database.

At implementation time the local API health endpoint is available, but the
Measurement list returns `measurement_service_unavailable`. A populated live-DB
acceptance run is still required after the team's data connection is ready.
