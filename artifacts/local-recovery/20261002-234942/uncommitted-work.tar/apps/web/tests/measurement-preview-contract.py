"""Validate synthetic UI previews against the real backend without database access."""

import json
import sys
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "apps" / "api"))

from app.modules.ledger.schemas import MeasurementLineageResult  # noqa: E402
from app.modules.measurement.schemas import MeasurementDetail, MeasurementSummary  # noqa: E402
from app.modules.semantic.schemas import ContextEnvelope, MetricDefinitionList  # noqa: E402

fixture_path = ROOT / "apps/web/src/features/measurements/preview/measurements.synthetic.json"
fixture = json.loads(fixture_path.read_text(encoding="utf-8"))
assert fixture["synthetic"] is True
ContextEnvelope.model_validate(fixture["context"])
MetricDefinitionList.model_validate(fixture["metrics"])
for record in fixture["records"]:
    summary = MeasurementSummary.model_validate(record["summary"])
    detail = MeasurementDetail.model_validate(record["detail"])
    lineage = MeasurementLineageResult.model_validate(record["lineage"])
    assert summary.id == detail.id == lineage.measurement_id
    assert summary.value_kgco2e == detail.value_kgco2e
    assert summary.confidence == detail.confidence_breakdown.overall
    assert str(summary.company_id) == fixture["scope"]["company_id"]
    assert str(summary.site_id) == fixture["scope"]["site_id"]
    assert str(summary.reporting_period_id) == fixture["scope"]["reporting_period_id"]
    for calculation in detail.calculations:
        assert calculation.emissions_kgco2e == (
            calculation.normalized_quantity_kg * calculation.factor_kgco2e_per_kg
        ).quantize(Decimal("0.000001"))
    nodes = {node.id for node in lineage.nodes}
    assert all(edge.source in nodes and edge.target in nodes for edge in lineage.edges)
print(f"Validated {len(fixture['records'])} synthetic records against backend contracts.")
