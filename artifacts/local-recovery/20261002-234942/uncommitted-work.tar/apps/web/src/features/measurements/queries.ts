import { queryOptions } from '@tanstack/react-query'
import { z } from 'zod'

import type { WorkspaceScope } from '@/lib/workspace'
import { contextSchema } from '@/schemas/context'
import { ApiError, apiRequest, retryApiQuery } from '@/services/api'
import {
  measurementDetailSchema,
  measurementLineageSchema,
  measurementListSchema,
  metricsSchema,
  type MeasurementFilters,
  type MeasurementSource,
} from './schemas'

export const measurementKey = ['measurements'] as const
type ListFilters = Pick<
  MeasurementFilters,
  'status' | 'category' | 'limit' | 'offset'
>

function inScope(
  item: { company_id: string; site_id: string; reporting_period_id: string },
  scope: WorkspaceScope,
) {
  return (
    item.company_id === scope.company_id &&
    item.site_id === scope.site_id &&
    item.reporting_period_id === scope.reporting_period_id
  )
}

// Preview is a separate development-only source, never a catch/fallback for API errors.
async function preview<T>(
  schema: z.ZodType<T>,
  signal: AbortSignal,
  getData: (source: typeof import('./preview/source')) => unknown,
) {
  if (!import.meta.env.DEV)
    throw new ApiError(
      'Synthetic preview is unavailable in this build.',
      'unsupported',
    )
  const source = await import('./preview/source')
  signal.throwIfAborted()
  const parsed = schema.safeParse(getData(source))
  if (!parsed.success)
    throw new ApiError(
      'Synthetic fixture does not match the API contract.',
      'invalid_preview',
    )
  return parsed.data
}

export const measurementQueries = {
  list: (
    scope: WorkspaceScope,
    source: MeasurementSource,
    filters: ListFilters,
  ) => {
    const schema = measurementListSchema.refine((page) =>
      page.items.every(
        (item) =>
          inScope(item, scope) &&
          (filters.status === 'all' || item.status === filters.status) &&
          (!filters.category || item.category === filters.category),
      ),
    )
    return queryOptions({
      queryKey: [...measurementKey, source, scope, 'list', filters],
      queryFn: ({ signal }) =>
        source === 'preview' && import.meta.env.DEV
          ? preview(schema, signal, (data) => data.previewList(scope, filters))
          : apiRequest('/measurements', schema, {
              signal,
              params: {
                company_id: scope.company_id,
                site_id: scope.site_id,
                reporting_period_id: scope.reporting_period_id,
                status: filters.status === 'all' ? undefined : filters.status,
                category: filters.category || undefined,
                limit: filters.limit,
                offset: filters.offset,
              },
            }),
      staleTime: 30_000,
      retry: retryApiQuery,
    })
  },
  detail: (scope: WorkspaceScope, source: MeasurementSource, id: string) => {
    const schema = measurementDetailSchema.refine(
      (item) => item.id === id && inScope(item, scope),
    )
    return queryOptions({
      queryKey: [...measurementKey, source, scope, 'detail', id],
      queryFn: ({ signal }) =>
        source === 'preview' && import.meta.env.DEV
          ? preview(
              schema,
              signal,
              (data) => data.previewRecord(scope, id).detail,
            )
          : apiRequest(`/measurements/${id}`, schema, {
              signal,
              params: { company_id: scope.company_id },
            }),
      staleTime: 30_000,
      retry: retryApiQuery,
    })
  },
  lineage: (scope: WorkspaceScope, source: MeasurementSource, id: string) => {
    const schema = measurementLineageSchema.refine(
      (item) => item.measurement_id === id,
    )
    return queryOptions({
      queryKey: [...measurementKey, source, scope, 'lineage', id],
      queryFn: ({ signal }) =>
        source === 'preview' && import.meta.env.DEV
          ? preview(
              schema,
              signal,
              (data) => data.previewRecord(scope, id).lineage,
            )
          : apiRequest(`/measurements/${id}/lineage`, schema, {
              signal,
              params: { company_id: scope.company_id },
            }),
      staleTime: 30_000,
      retry: retryApiQuery,
    })
  },
  metrics: (scope: WorkspaceScope, source: MeasurementSource) => {
    const schema = metricsSchema.refine(
      (item) => item.company_id === scope.company_id,
    )
    return queryOptions({
      queryKey: [...measurementKey, source, scope.company_id, 'metrics'],
      queryFn: ({ signal }) =>
        source === 'preview' && import.meta.env.DEV
          ? preview(schema, signal, (data) => data.previewData(scope).metrics)
          : apiRequest('/semantic/metrics', schema, {
              signal,
              params: { company_id: scope.company_id, active_only: true },
            }),
      staleTime: 60_000,
      retry: retryApiQuery,
    })
  },
  context: (scope: WorkspaceScope, source: MeasurementSource) => {
    const schema = contextSchema.refine(
      (item) =>
        item.company.id === scope.company_id &&
        item.site.id === scope.site_id &&
        item.reporting_period.id === scope.reporting_period_id,
    )
    return queryOptions({
      queryKey: [...measurementKey, source, scope, 'context'],
      queryFn: ({ signal }) =>
        source === 'preview' && import.meta.env.DEV
          ? preview(schema, signal, (data) => data.previewData(scope).context)
          : apiRequest('/context/resolve', schema, {
              signal,
              body: {
                company_id: scope.company_id,
                site_id: scope.site_id,
                reporting_period_id: scope.reporting_period_id,
                metric_definition_ids: [scope.metric_id],
                workflow: 'measurement',
              },
            }),
      staleTime: 60_000,
      retry: retryApiQuery,
    })
  },
}
