import type { WorkspaceScope } from '@/lib/workspace'
import { ApiError } from '@/services/api'
import type { MeasurementFilters } from '../schemas'
import fixture from './measurements.synthetic.json'

export function previewData(scope: WorkspaceScope) {
  if (
    Object.keys(fixture.scope).some(
      (key) =>
        fixture.scope[key as keyof WorkspaceScope] !==
        scope[key as keyof WorkspaceScope],
    )
  ) {
    throw new ApiError(
      'This preview only covers the configured Maverick synthetic context.',
      'preview_context_mismatch',
    )
  }
  return fixture
}

export function previewList(
  scope: WorkspaceScope,
  filters: Pick<MeasurementFilters, 'status' | 'category' | 'limit' | 'offset'>,
) {
  const items = previewData(scope)
    .records.map((record) => record.summary)
    .filter(
      (item) => filters.status === 'all' || item.status === filters.status,
    )
    .filter((item) => !filters.category || item.category === filters.category)
    .sort(
      (a, b) =>
        b.created_at.localeCompare(a.created_at) || b.id.localeCompare(a.id),
    )
  return {
    items: items.slice(filters.offset, filters.offset + filters.limit),
    total: items.length,
    limit: filters.limit,
    offset: filters.offset,
  }
}

export function previewRecord(scope: WorkspaceScope, id: string) {
  const record = previewData(scope).records.find(
    (item) => item.summary.id === id,
  )
  if (!record)
    throw new ApiError(
      'This record is not part of the synthetic preview.',
      'measurement_not_found',
    )
  return record
}
